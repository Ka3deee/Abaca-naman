<img src="{{ asset('images/abacanaman-admin-logo.jpg') }}" alt="Logo" class="h-10">
