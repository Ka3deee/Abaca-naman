<img src="{{ asset('images/abacanaman-logo.jpg') }}" alt="Logo" class="h-10">
