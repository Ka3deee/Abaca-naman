<img src="{{ asset('images/abacanaman-seller-logo.jpg') }}" alt="Logo" class="h-10">
