<x-filament::page>
  <p>Hello World</p>
</x-filament::page>
